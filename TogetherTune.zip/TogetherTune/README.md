# TogetherTune

Two friends call each other and listen to the same song together.

## Build the APK (on a computer)
1. Install Android Studio.
2. File > Open, and choose this TogetherTune folder.
3. Wait for the Gradle sync to finish (needs internet, the first time takes a while).
   If Android Studio offers to upgrade the Android Gradle Plugin, you can skip it.
4. To test: connect your phone with USB debugging on and press the green Run button.
5. To get the APK: Build > Build Bundle(s) / APK(s) > Build APK(s) > locate.
   The file is app/build/outputs/apk/debug/app-debug.apk
6. Install it on both phones, join the same room code, and talk.

## Settings in app/src/main/java/com/example/togethertune/MainActivity.kt
- APP_ID: your Agora App ID (keep it private).
- TOKEN: leave empty in Agora testing mode. In secured mode, paste a temporary token.
- SONGS: test tracks only. Use licensed or free-library music before publishing.

## Online build (optional)
.github/workflows/build-apk.yml builds the APK on GitHub. Upload the whole project
to a GitHub repository, open the Actions tab, run "Build APK", then download the file.

## Versions used
Android Gradle Plugin 8.13.2, Gradle 8.13, Kotlin 2.3.0, Compose BOM 2026.04.01,
Media3 1.10.1, Agora Voice SDK 4.6.2, minSdk 26, compileSdk 36. Needs JDK 17.
