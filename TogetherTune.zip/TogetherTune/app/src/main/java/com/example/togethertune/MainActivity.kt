// TogetherTune - voice call with a friend plus songs you both hear at the same time.
// Calls use Agora. Songs play on each phone with ExoPlayer and are kept in sync
// with small messages sent through the call connection.
//
// Things you may want to change below: APP_ID, TOKEN and the SONGS list.

package com.example.togethertune

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.DataStreamConfig
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import kotlinx.coroutines.delay
import org.json.JSONObject

// Your Agora App ID. Keep it private: anyone who has it can use your free minutes.
private const val APP_ID = "f866c210ecc642e69047f047b5399054"

// Leave empty while your Agora project is in testing mode (App ID only).
// If your project is in secured mode, paste a temporary token from the Agora Console here.
private const val TOKEN = ""

private data class Song(val title: String, val url: String)

// Test tracks. Open each link in a browser once to check it still plays.
private val SONGS = listOf(
    Song("Test song 1", "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"),
    Song("Test song 2", "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"),
    Song("Test song 3", "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3")
)

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

class MainActivity : ComponentActivity() {

    private var engine: RtcEngine? = null
    private lateinit var player: ExoPlayer
    private var streamId = -1

    // Screen state
    private var status by mutableStateOf("Not in a call")
    private var inCall by mutableStateOf(false)
    private var muted by mutableStateOf(false)
    private var currentSong by mutableStateOf<Int?>(null)
    private var isPlaying by mutableStateOf(false)
    private var songBy by mutableStateOf("")
    private var songVolume by mutableStateOf(0.8f) // 0.0 to 1.0, only for this phone

    // ---------- Agora events ----------
    private val handler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            // The data stream is the channel we use to send song commands to your friend.
            streamId = engine?.createDataStream(DataStreamConfig().apply {
                ordered = true
                syncWithAudio = false
            }) ?: -1
            runOnUiThread {
                inCall = true
                status = "You are in the room. Waiting for your friend..."
            }
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            runOnUiThread {
                status = "Your friend joined. You can talk now."
                // Give the friend's phone a moment to get ready, then tell it what is playing.
                Handler(Looper.getMainLooper()).postDelayed({ sendCurrentState() }, 1500)
            }
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            runOnUiThread { status = "Your friend left the call." }
        }

        override fun onStreamMessage(uid: Int, streamId: Int, data: ByteArray?) {
            if (data == null) return
            val text = String(data)
            runOnUiThread { handleMessage(text) }
        }

        override fun onError(err: Int) {
            runOnUiThread { status = "Error code: $err" }
        }
    }

    // ---------- Call ----------
    private fun startCall(room: String) {
        try {
            if (engine == null) {
                val config = RtcEngineConfig().apply {
                    mContext = applicationContext
                    mAppId = APP_ID
                    mEventHandler = handler
                }
                engine = RtcEngine.create(config)
            }
            val options = ChannelMediaOptions().apply {
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                publishMicrophoneTrack = true
            }
            engine?.setEnableSpeakerphone(true)
            engine?.joinChannel(TOKEN.ifEmpty { null }, room, 0, options)
            status = "Connecting..."
        } catch (e: Exception) {
            status = "Could not start the call: ${e.message}"
        }
    }

    private fun endCall() {
        engine?.leaveChannel()
        player.stop()
        player.clearMediaItems()
        currentSong = null
        isPlaying = false
        streamId = -1
        inCall = false
        muted = false
        status = "Not in a call"
    }

    private fun toggleMute() {
        muted = !muted
        engine?.muteLocalAudioStream(muted)
    }

    // ---------- Music ----------
    // Each person sets the song volume on their own phone.
    private fun setSongVolume(v: Float) {
        songVolume = v.coerceIn(0f, 1f)
        player.volume = songVolume
    }

    private fun loadSong(index: Int, posMs: Long, play: Boolean) {
        currentSong = index
        player.setMediaItem(MediaItem.fromUri(SONGS[index].url))
        player.prepare()
        player.seekTo(posMs)
        player.playWhenReady = play
        isPlaying = play
    }

    private fun pickSong(index: Int) {
        songBy = "You"
        loadSong(index, 0L, true)
        send(JSONObject().put("t", "load").put("song", index).put("pos", 0L).put("play", true))
    }

    private fun togglePlay() {
        val nowPlaying = !isPlaying
        player.playWhenReady = nowPlaying
        isPlaying = nowPlaying
        send(
            JSONObject()
                .put("t", if (nowPlaying) "resume" else "pause")
                .put("pos", player.currentPosition)
        )
    }

    private fun sendCurrentState() {
        val song = currentSong ?: return
        send(
            JSONObject().put("t", "load").put("song", song)
                .put("pos", player.currentPosition).put("play", isPlaying)
        )
    }

    private fun send(message: JSONObject) {
        if (streamId < 0) return
        engine?.sendStreamMessage(streamId, message.toString().toByteArray())
    }

    // Runs when your friend sends a song command.
    private fun handleMessage(text: String) {
        try {
            val m = JSONObject(text)
            when (m.getString("t")) {
                "load" -> {
                    songBy = "Your friend"
                    loadSong(m.getInt("song"), m.getLong("pos"), m.getBoolean("play"))
                }
                "pause" -> {
                    player.pause()
                    player.seekTo(m.getLong("pos"))
                    isPlaying = false
                }
                "resume" -> {
                    player.seekTo(m.getLong("pos"))
                    player.play()
                    isPlaying = true
                }
            }
        } catch (e: Exception) {
            status = "Could not read a message from your friend"
        }
    }

    // ---------- Screen ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        player = ExoPlayer.Builder(this).build().apply {
            // false = do not stop the music when the call takes audio focus
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                false
            )
        }
        player.volume = songVolume

        setContent {
            MaterialTheme {
                var room by remember { mutableStateOf("") }
                var posMs by remember { mutableStateOf(0L) }

                // Update the time shown for the song twice a second.
                LaunchedEffect(Unit) {
                    while (true) {
                        posMs = if (currentSong != null) player.currentPosition else 0L
                        delay(500)
                    }
                }

                val askMic = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    if (granted) startCall(room.trim().uppercase())
                    else status = "The microphone permission is needed for calls"
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("TogetherTune", style = MaterialTheme.typography.headlineLarge)
                    Spacer(Modifier.height(24.dp))

                    OutlinedTextField(
                        value = room,
                        onValueChange = { room = it },
                        label = { Text("Room code") },
                        singleLine = true,
                        enabled = !inCall
                    )
                    Spacer(Modifier.height(16.dp))

                    if (!inCall) {
                        Button(
                            enabled = room.trim().length >= 4,
                            onClick = {
                                val hasMic = ContextCompat.checkSelfPermission(
                                    this@MainActivity, Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (hasMic) startCall(room.trim().uppercase())
                                else askMic.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        ) { Text("Join call") }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(onClick = { toggleMute() }) {
                                Text(if (muted) "Unmute" else "Mute")
                            }
                            Button(onClick = { endCall() }) { Text("End call") }
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    Text(status)

                    if (inCall) {
                        Spacer(Modifier.height(24.dp))
                        val song = currentSong
                        if (song != null) {
                            val dur = if (player.duration > 0) player.duration else 0L
                            Text(SONGS[song].title, style = MaterialTheme.typography.titleLarge)
                            Text("$songBy picked this song. Both of you hear it.")
                            Text("${fmt(posMs)} / ${fmt(dur)}")
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { togglePlay() }) {
                                Text(if (isPlaying) "Pause for both" else "Play for both")
                            }
                            Spacer(Modifier.height(16.dp))
                        }
                        Text(
                            "Song volume: ${(songVolume * 100).toInt()}%",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(onClick = { setSongVolume(songVolume - 0.1f) }) { Text("-") }
                            Slider(
                                value = songVolume,
                                onValueChange = { setSongVolume(it) },
                                valueRange = 0f..1f,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedButton(onClick = { setSongVolume(songVolume + 0.1f) }) { Text("+") }
                        }
                        Text(
                            "This changes the song volume on your phone only.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(16.dp))
                        Text("Pick a song", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        SONGS.forEachIndexed { i, s ->
                            OutlinedButton(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { pickSong(i) }
                            ) { Text(s.title) }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        engine?.leaveChannel()
        RtcEngine.destroy()
        engine = null
        player.release()
    }
}
